package com.mailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMailDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
