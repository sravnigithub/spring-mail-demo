package com.mailservice.controllers;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.mailservice.service.IEmailService;

@RestController
public class EmailController { 
	//responsible for sending mail to other person
	private IEmailService emailService;
	public EmailController(IEmailService emailService) {
		super();
		this.emailService=emailService;
	}
	
	@PostMapping
	
public String sendMail(String to,String[] cc,String subject,String body) {
		String result= emailService.sendMail(to,cc,subject,body);
		return result;
	
}
}
