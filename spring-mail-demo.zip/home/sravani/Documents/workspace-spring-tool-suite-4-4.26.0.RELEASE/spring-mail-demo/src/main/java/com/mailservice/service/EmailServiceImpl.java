package com.mailservice.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.SimpleMailMessage;

@Service
public class EmailServiceImpl implements IEmailService {
	
	@Autowired
	
	private JavaMailSender mailSender;
	
	public String sendMail(String to,String[] cc,String subject,String body) {
		//content to body no attachements
		
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo(to);
		message.setCc(cc);
		message.setSubject(subject);
		message.setText(body);
		//send mesg using java mail sender
		mailSender.send(message);
		
		
		return "mail send successfully";
	
	}	

}
